# Tki ( Toolkit-InterFace ) 
___
### 将`Tkinter`组件封装升级，更新更多组件，缩短开发周期。


# 快速入手
___
```python
from Tki.KiWidgets import *  # 导入

Window = KiWindow()  # 设置窗口
Window.Run()  # 运行窗口
```